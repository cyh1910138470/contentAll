const axios = require('axios')
const datasAllAPI = require('./api/datasAll')

async function dataHandler(dataNow) {
  const datasAll = await datasAllAPI()

  const LocalExistingConfirm = {
    key: "LocalExistingConfirm", //本土现有确诊
    value: dataNow.data.chinaTotal.today.confirm
  }
  const ExistingConfirm = {
    key: "ExistingConfirm",//现有确诊
    value: datasAll.data.domesticStatistics.currentConfirmedCount
  }
  const TotalConfirm = {
    key: "TotalConfirm",//累计确诊
    value: datasAll.data.domesticStatistics.confirmedCount
  }
  const noSymptom = {
    key: "noSymptom",//无症状感染者
    value: datasAll.data.domesticStatistics.seriousCount
  }
  const incrNoSymptom = {
    key: "incrNoSymptom",//无症状感染者新增
    value: dataNow.data.chinaTotal.extData.incrNoSymptom
  }
  const inputTotal = {
    key: "inputTotal",//境外输入
    value: datasAll.data.domesticStatistics.suspectedCount
  }
  const inputIncrement = {
    key: "inputIncrement",//境外输入新增
    value: dataNow.data.chinaTotal.today.input
  }
  const TotalDead = {
    key: "TotalDead",//累计死亡
    value: datasAll.data.domesticStatistics.deadCount
  }
  const TotalDeadIncrement = {
    key: "TotalDeadIncrement",//累计死亡新增
    value: dataNow.data.chinaTotal.today.dead
  }

  const AboradArray = dataNow.data.areaTree
  let AbroadExistingConfirmValue = 0
  let AbroadConfirmValue = 0
  let AbroadHealValue = 0
  let AbroadDeadValue = 0
  for (let item of AboradArray) {
    AbroadExistingConfirmValue += item.today.confirm
    AbroadConfirmValue += item.total.confirm
    AbroadHealValue += item.total.heal
    AbroadDeadValue += item.total.dead
  }
  const AbroadExistingConfirm = {
    key: "AbroadExistingConfirm",//海外现有确诊
    value: datasAll.data.internationalStatistics.currentConfirmedCount
  }
  const AbroadConfirm = {
    key: "AbroadConfirm",//海外累计确诊
    value: datasAll.data.internationalStatistics.confirmedCount
  }
  const AbroadHeal = {
    key: "AbroadHeal",//海外累计治愈
    value: datasAll.data.internationalStatistics.curedCount
  }
  const AbroadDead = {
    key: "AbroadDead",//海外累计死亡
    value: datasAll.data.internationalStatistics.deadCount
  }

  // const chinaProvinceData = AboradArray[2].children
  // const chinaProvinceArrays = []
  // for (let item of chinaProvinceData) {
  //   let obj = {}
  //   obj["name"] = item.name
  //   obj["attributes"] = {}
  //   obj["attributes"]["confirmToday"] = item.today.confirm
  //   obj["attributes"]["healToday"] = item.today.heal
  //   obj["attributes"]["deadToday"] = item.today.dead
  //   obj["attributes"]["confirmTotal"] = item.total.confirm
  //   obj["attributes"]["healTotal"] = item.total.heal
  //   obj["attributes"]["deadTotal"] = item.total.dead
  //   chinaProvinceArrays.push = obj
  // }

  const chinaProvinceData = AboradArray[2].children
  // const chinaProvinceArrays = []
  // for (let item of chinaProvinceData) {
  //   let obj = {}
  //   obj["name"] = item.name
  //   obj["attributes"] = {}
  //   obj["attributes"]["confirmToday"] = item.today.confirm
  //   obj["attributes"]["healToday"] = item.today.heal
  //   obj["attributes"]["deadToday"] = item.today.dead
  //   obj["attributes"]["confirmTotal"] = item.total.confirm
  //   obj["attributes"]["healTotal"] = item.total.heal
  //   obj["attributes"]["deadTotal"] = item.total.dead
  //   chinaProvinceArrays.push = obj
  // }
  const docker = []
  for (let item of chinaProvinceData) {
    const obj = {}
    obj.name = item.name
    obj.TotalConfirm = item.total.confirm
    obj.TotalHeal = item.total.heal
    obj.TotalDead = item.total.dead
    docker.push(obj)
  }
  const Provinces = {
    key: "Provinces",
    value: docker
  }
  const lastUpdateTime = {
    key: "lastUpdateTime",
    value: datasAll.data.modifyTime
  }

  const timeStr = datasAll.data.modifyTime;
  const reg = /[1-9][0-9]*/g
  const timeArray = timeStr.match(reg);
  timeArray.forEach((item, index) => {
    if (item.length === 1) {
      timeArray[index] = 0 + item;
    }
  })
  const timeYear = {
    key: 'timeYear',
    value: Number(timeArray[0])
  }
  const timeMonth = {
    key: 'timeMonth',
    value: Number(timeArray[1])
  }
  const timeDay = {
    key: 'timeDay',
    value: Number(timeArray[2])
  }
  const timeHour = {
    key: 'timeHour',
    value: Number(timeArray[3])
  }
  const timeMinute = {
    key: 'timeMinute',
    value: Number(timeArray[4])
  }
  const timeSecond = {
    key: 'timeSecond',
    value: Number(timeArray[5])
  }

  const date = new Date();
  const seconds = date.getTime();
  const offset = date.getTimezoneOffset() * 60000;
  const utcTime = seconds + offset;
  const timeNow = utcTime + 3600000 * 8;
  const timeformat = formatTime(timeNow, 'yyyy-mm-dd hh:mi:ss SSS');
  const array = timeformat.match(reg);
  let hourDiff = 100
  let minuteDiff = 100
  if (array[4] < timeArray[4]) {
    hourDiff = Number(array[3]) - Number(timeArray[3]) - 1
    minuteDiff = 60 - Number(timeArray[4]) + Number(array[4])
  } else {
    hourDiff = Number(array[3]) - Number(timeArray[3])
    minuteDiff = Number(array[4]) - Number(timeArray[4])
  }
  const hourDiffs = {
    key: 'hourDiffs',
    value: hourDiff
  }
  const minuteDiffs = {
    key: 'minuteDiffs',
    value: minuteDiff
  }

  const arrayDatas = [LocalExistingConfirm, ExistingConfirm, TotalConfirm, noSymptom, incrNoSymptom, inputTotal,
    inputIncrement, TotalDead, TotalDeadIncrement, AbroadExistingConfirm, AbroadConfirm, AbroadHeal, AbroadDead,
    Provinces, lastUpdateTime, timeYear, timeMonth, timeDay, timeHour, timeMinute, timeSecond, hourDiffs, minuteDiffs
  ]

  return arrayDatas
}

function obj(array) {
  let objects = {}
  for (let item of array) {
    objects[item.key] = item.value
  }
  return objects
}

   function formatTime(timestamps, format) {
    var date = new Date(timestamps);
    var finalstr=format;
    finalstr=finalstr.replace('yyyy', date.getFullYear());//年
    finalstr=finalstr.replace('mm', formatNum(date.getMonth() + 1));//月
    finalstr=finalstr.replace('dd', formatNum(date.getDate()));//天
    finalstr=finalstr.replace('hh',formatNum(date.getHours()));//时
    finalstr=finalstr.replace('mi', formatNum(date.getMinutes()));//分
    finalstr=finalstr.replace('ss', formatNum(date.getSeconds()));//秒
    finalstr=finalstr.replace('SSS', formatMilliseconds(date.getMilliseconds()));//毫秒
    //如果不想返回秒和毫秒，注释掉相应行数，传入参数时去掉该参数
    return finalstr;
}

function formatNum(arg0) {
    let str = arg0.toString();
    if (str.length == 1) {
        return "0" + str;
    } else {
        return str;
    }
}

function formatMilliseconds(arg) {
    var str = arg.toString();
    if (str.length == 1) {
        return "00" + str;
    } else if (str.length == 2) {
        return "0" + str;
    } else if (str.length == 3) {
        return str;
    }
}

exports.dataHandler = dataHandler
exports.obj = obj
