const express = require('express')
const axios = require('axios')
const fs = require('fs')
const utils = require("./utils")
const dataHandler = utils.dataHandler
const obj = utils.obj
const app = express()
const datasAll = require('./api/datasAll')

let times = 0



app.get('/', async function(request, response) {
  response.setHeader("Access-Control-Allow-Origin", "*");
  response.setHeader("Access-Control-Allow-Headers", "*");
  response.setHeader("Access-Control-Allow-Method", "*");
  axios({
    method: 'get',
    url: 'https://c.m.163.com/ug/api/wuhan/app/data/list-total'
  }).then(response => {
    fs.writeFileSync('./data.json', JSON.stringify(response.data), (err, data) => {
      console.log(err);
    })
  })
    const dataNow = fs.readFileSync('./data.json', {encoding: 'utf-8'})
    let dataChange = JSON.parse(dataNow)
    const arrayres = await dataHandler(dataChange)
    const objs = obj(arrayres)
    response.send(JSON.stringify(objs))
  times++
  console.log(`累计收到${times}次请求 --------`);
})

app.get('/webpage', function (request, response) {
  // console.log(request);
  response.setHeader("Access-Control-Allow-Origin", "*");
  response.setHeader("Access-Control-Allow-Headers", "*");
  response.setHeader("Access-Control-Allow-Method", "*");
  const data = fs.readFileSync('./data.json', { encoding: 'utf-8' })
  response.send(data)
  times++;
  console.log(`收到${times}次请求`);
})

app.get('/datasall', async (request, response) => {
  // const res = await axios({
  //   method: 'get',
  //   url: 'http://111.231.75.86:8000/api/statistics/latest'
  // })
  // console.log(res);
  // response.send(res)
  // response.send(JSON.stringify(res.data))
  response.send('123')
  console.log(`收到${times}次请求`);
})

app.get('/test', function (request, response) {
  response.send('test')
  console.log('test请求');
})

app.listen(3000, function() {
  console.log('服务已经启动 3000端口正在监听');
})
