// const timeStr = "2022-04-10 10:59:09";
// const reg = /[1-9][0-9]*/g
// const array = timeStr.match(reg);
// array.forEach((item, index) => {
//   if (item.length === 1) {
//     array[index] = 0 + item;
//   }
// })
const date = new Date();
const seconds = date.getTime();
const offset = date.getTimezoneOffset() * 60000;
const utcTime = seconds + offset;
const timeNow = utcTime + 3600000 * 8;
console.log(timeNow);


  /**
     * 将时间戳转化为年 月 日 时 分 秒
     * timestamps: 传入的时间戳
     * format：返回格式，支持自定义，如：
     * yyyy-mm-dd hh:mi:ss SSS
     * yyyy/mm/dd hh:mi:ss SSS
     * 获取日期格式字符串作为主键：yyyymmddhhmissSSS
     */
   function formatTime(timestamps, format) {
    var date = new Date(timestamps);
    var finalstr=format;
    finalstr=finalstr.replace('yyyy', date.getFullYear());//年
    finalstr=finalstr.replace('mm', formatNum(date.getMonth() + 1));//月
    finalstr=finalstr.replace('dd', formatNum(date.getDate()));//天
    finalstr=finalstr.replace('hh',formatNum(date.getHours()));//时
    finalstr=finalstr.replace('mi', formatNum(date.getMinutes()));//分
    finalstr=finalstr.replace('ss', formatNum(date.getSeconds()));//秒
    finalstr=finalstr.replace('SSS', formatMilliseconds(date.getMilliseconds()));//毫秒
    //如果不想返回秒和毫秒，注释掉相应行数，传入参数时去掉该参数
    return finalstr;
}

//月，天，时，分，秒不足补位,
// 返回的值是一个两位的数字。不过返回值不总是两位的，如果该值小于 10，则仅返回一位数字
//如00点，只会返回一个数字0；6:00正的分钟数返回的是一个0
function formatNum(arg0) {
    let str = arg0.toString();
    if (str.length == 1) {
        return "0" + str;
    } else {
        return str;
    }
}

//毫秒补位
function formatMilliseconds(arg) {
    var str = arg.toString();
    if (str.length == 1) {
        return "00" + str;
    } else if (str.length == 2) {
        return "0" + str;
    } else if (str.length == 3) {
        return str;
    }
}
const timeformat = formatTime(timeNow, 'yyyy-mm-dd hh:mi:ss SSS');
console.log(timeformat);

const timeStr = timeformat
const reg = /[1-9][0-9]*/g
const array = timeStr.match(reg);
console.log(array);
