const axios = require('axios')

async function datasAll() {
  const res = await axios({
    url: 'http://111.231.75.86:8000/api/statistics/latest',
    method: 'get'
  })
  return res
}

module.exports = datasAll
